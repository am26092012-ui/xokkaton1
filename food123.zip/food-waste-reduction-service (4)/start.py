#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Скрипт для быстрого запуска FoodSaver
"""

import os
import sys

def check_dependencies():
    """Проверка установленных зависимостей"""
    try:
        import fastapi
        import uvicorn
        import jinja2
        print("✅ Все зависимости установлены!")
        return True
    except ImportError as e:
        print(f"❌ Не установлены зависимости: {e}")
        print("\nУстановите зависимости командой:")
        print("pip install -r requirements.txt")
        return False

def main():
    """Главная функция запуска"""
    print("=" * 70)
    print(" " * 20 + "🍽️  FOODSAVER  🍽️")
    print(" " * 10 + "Сервис продажи продуктов со скидкой")
    print("=" * 70)
    print()
    
    if not check_dependencies():
        sys.exit(1)
    
    print("\n🚀 Запуск сервера...")
    print("📍 Адрес: http://localhost:8000")
    print("📋 Документация API: http://localhost:8000/docs")
    print("\n⌨️  Нажмите Ctrl+C для остановки сервера\n")
    print("-" * 70)
    
    # Импортируем и запускаем приложение
    try:
        from main import app
        import uvicorn
        uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
    except KeyboardInterrupt:
        print("\n\n👋 Сервер остановлен. До свидания!")
    except Exception as e:
        print(f"\n❌ Ошибка при запуске: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
