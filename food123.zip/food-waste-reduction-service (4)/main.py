from fastapi import FastAPI, Request, Form, HTTPException, Cookie
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from datetime import datetime, timedelta
from typing import Optional
import uvicorn
from dataclasses import dataclass, asdict
from enum import Enum
import random
import hashlib
import secrets

app = FastAPI(title="FoodSaver - Сервис продажи продуктов со скидкой")
templates = Jinja2Templates(directory="templates")


# Модели данных
class ProductCategory(str, Enum):
    BAKERY = "Хлебобулочные изделия"
    DAIRY = "Молочные продукты"
    MEAT = "Мясные изделия"
    READY = "Готовые блюда"
    DESSERT = "Десерты"
    DRINKS = "Напитки"


class OrderStatus(str, Enum):
    NEW = "Новый"
    CONFIRMED = "Подтвержден"
    IN_DELIVERY = "В доставке"
    COMPLETED = "Завершен"
    CANCELLED = "Отменен"


@dataclass
class Product:
    id: int
    name: str
    category: ProductCategory
    original_price: float
    discount: int  # процент скидки
    quantity: int
    expiry_date: datetime
    seller_name: str
    seller_id: int
    image_url: str
    description: str
    
    @property
    def discounted_price(self):
        return round(self.original_price * (1 - self.discount / 100), 2)
    
    @property
    def hours_left(self):
        delta = self.expiry_date - datetime.now()
        return max(0, int(delta.total_seconds() / 3600))
    
    @property
    def urgency_level(self):
        hours = self.hours_left
        if hours < 6:
            return "critical"
        elif hours < 12:
            return "high"
        elif hours < 24:
            return "medium"
        else:
            return "low"


@dataclass
class User:
    id: int
    username: str
    email: str
    password_hash: str
    full_name: str
    phone: str
    address: str
    created_at: datetime
    is_seller: bool = False
    avatar: str = "👤"
    
    
@dataclass
class Seller:
    id: int
    name: str
    address: str
    phone: str
    email: str
    rating: float
    total_saved: float  # сколько продуктов спасено от утилизации (кг)
    user_id: Optional[int] = None


@dataclass
class Order:
    id: int
    product_id: int
    buyer_name: str
    buyer_phone: str
    buyer_address: str
    quantity: int
    total_price: float
    status: OrderStatus
    created_at: datetime
    delivery_time: Optional[datetime] = None


# Хранилище данных в памяти
users_db = {}
sellers_db = {}
products_db = {}
orders_db = {}
sessions_db = {}  # session_token -> user_id

# Счетчики ID
user_id_counter = 1
seller_id_counter = 1
product_id_counter = 1
order_id_counter = 1


# Утилиты для аутентификации
def hash_password(password: str) -> str:
    """Хеширование пароля"""
    return hashlib.sha256(password.encode()).hexdigest()


def create_session(user_id: int) -> str:
    """Создание сессии"""
    session_token = secrets.token_urlsafe(32)
    sessions_db[session_token] = user_id
    return session_token


def get_current_user(session_token: Optional[str]) -> Optional[User]:
    """Получение текущего пользователя"""
    if not session_token:
        return None
    user_id = sessions_db.get(session_token)
    if not user_id:
        return None
    return users_db.get(user_id)


# Инициализация тестовых данных
def init_test_data():
    global user_id_counter, seller_id_counter, product_id_counter, users_db, sellers_db, products_db
    
    # Создаем тестовых пользователей
    test_users = [
        User(1, "demo", "demo@foodsaver.com", hash_password("demo123"), "Демо Пользователь", "+380501111111", "ул. Тестовая, 1", datetime.now(), False, "😊"),
        User(2, "seller1", "seller1@foodsaver.com", hash_password("seller123"), "Владимир Пекарь", "+380502222222", "ул. Хлебная, 10", datetime.now(), True, "🧑‍🍳"),
        User(3, "admin", "admin@foodsaver.com", hash_password("admin123"), "Админ Админов", "+380503333333", "ул. Главная, 1", datetime.now(), True, "👨‍💼"),
    ]
    
    for user in test_users:
        users_db[user.id] = user
    user_id_counter = len(test_users) + 1
    
    # Создаем тестовых продавцов
    test_sellers = [
        Seller(1, "Пекарня 'Свежий хлеб'", "ул. Пушкина, 10", "+380501234567", "bread@example.com", 4.8, 1250.5, 2),
        Seller(2, "Кафе 'Домашняя еда'", "пр. Независимости, 45", "+380501234568", "cafe@example.com", 4.6, 890.3, 2),
        Seller(3, "Мини-маркет 'У дома'", "ул. Лесная, 23", "+380501234569", "market@example.com", 4.9, 2100.7, 3),
        Seller(4, "Кондитерская 'Сладкий рай'", "ул. Центральная, 8", "+380501234570", "sweets@example.com", 4.7, 670.2, 3),
    ]
    
    for seller in test_sellers:
        sellers_db[seller.id] = seller
    seller_id_counter = len(test_sellers) + 1
    
    # Создаем тестовые продукты (ЦЕНЫ В РУБЛЯХ!)
    now = datetime.now()
    test_products = [
        Product(1, "Багет французский", ProductCategory.BAKERY, 89.0, 50, 15, 
                now + timedelta(hours=4), "Пекарня 'Свежий хлеб'", 1,
                "🥖", "Свежий французский багет с хрустящей корочкой"),
        Product(2, "Круассаны с шоколадом (5 шт)", ProductCategory.BAKERY, 250.0, 40, 8,
                now + timedelta(hours=8), "Пекарня 'Свежий хлеб'", 1,
                "🥐", "Слоеные круассаны с бельгийским шоколадом"),
        Product(3, "Молоко 2.5% (1л)", ProductCategory.DAIRY, 79.0, 30, 20,
                now + timedelta(hours=18), "Мини-маркет 'У дома'", 3,
                "🥛", "Пастеризованное молоко высшего качества"),
        Product(4, "Йогурт натуральный (400г)", ProductCategory.DAIRY, 65.0, 35, 12,
                now + timedelta(hours=12), "Мини-маркет 'У дома'", 3,
                "🥛", "Натуральный йогурт без добавок"),
        Product(5, "Котлеты домашние (500г)", ProductCategory.MEAT, 199.0, 45, 6,
                now + timedelta(hours=6), "Кафе 'Домашняя еда'", 2,
                "🍖", "Сочные котлеты из говядины, приготовлены сегодня"),
        Product(6, "Борщ с пампушками", ProductCategory.READY, 159.0, 40, 10,
                now + timedelta(hours=5), "Кафе 'Домашняя еда'", 2,
                "🍲", "Традиционный украинский борщ (600мл)"),
        Product(7, "Вареники с картошкой (800г)", ProductCategory.READY, 179.0, 35, 8,
                now + timedelta(hours=10), "Кафе 'Домашняя еда'", 2,
                "🥟", "Домашние вареники ручной лепки"),
        Product(8, "Торт 'Наполеон' (кусок)", ProductCategory.DESSERT, 129.0, 50, 6,
                now + timedelta(hours=7), "Кондитерская 'Сладкий рай'", 4,
                "🍰", "Классический торт с заварным кремом"),
        Product(9, "Эклеры (4 шт)", ProductCategory.DESSERT, 169.0, 45, 10,
                now + timedelta(hours=9), "Кондитерская 'Сладкий рай'", 4,
                "🧁", "Нежные эклеры с ванильным кремом"),
        Product(10, "Свежевыжатый сок апельсиновый (500мл)", ProductCategory.DRINKS, 119.0, 40, 7,
                now + timedelta(hours=3), "Кафе 'Домашняя еда'", 2,
                "🍊", "100% свежевыжатый сок без сахара"),
        Product(11, "Хлеб бородинский", ProductCategory.BAKERY, 69.0, 45, 12,
                now + timedelta(hours=6), "Пекарня 'Свежий хлеб'", 1,
                "🍞", "Ароматный бородинский хлеб на закваске"),
        Product(12, "Сырники со сметаной", ProductCategory.READY, 139.0, 50, 5,
                now + timedelta(hours=4), "Кафе 'Домашняя еда'", 2,
                "🥞", "Нежные сырники с домашней сметаной"),
        Product(13, "Пирожки с капустой (6 шт)", ProductCategory.BAKERY, 119.0, 40, 9,
                now + timedelta(hours=7), "Пекарня 'Свежий хлеб'", 1,
                "🥙", "Печеные пирожки с капустой"),
        Product(14, "Сметана 20% (400г)", ProductCategory.DAIRY, 89.0, 30, 15,
                now + timedelta(hours=20), "Мини-маркет 'У дома'", 3,
                "🥛", "Натуральная сметана высокой жирности"),
        Product(15, "Чизкейк 'Нью-Йорк' (кусок)", ProductCategory.DESSERT, 149.0, 45, 4,
                now + timedelta(hours=8), "Кондитерская 'Сладкий рай'", 4,
                "🍰", "Нежный чизкейк в американском стиле"),
    ]
    
    for product in test_products:
        products_db[product.id] = product
    product_id_counter = len(test_products) + 1


# Маршруты
@app.on_event("startup")
async def startup_event():
    init_test_data()


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, session: Optional[str] = Cookie(None)):
    """Страница входа"""
    user = get_current_user(session)
    if user:
        return RedirectResponse("/", status_code=303)
    
    return templates.TemplateResponse("login.html", {
        "request": request
    })


@app.post("/login")
async def login(
    response: Response,
    username: str = Form(...),
    password: str = Form(...)
):
    """Обработка входа"""
    password_hash = hash_password(password)
    
    # Поиск пользователя
    user = None
    for u in users_db.values():
        if u.username == username and u.password_hash == password_hash:
            user = u
            break
    
    if not user:
        raise HTTPException(status_code=400, detail="Неверный логин или пароль")
    
    # Создаем сессию
    session_token = create_session(user.id)
    
    # Редирект с установкой cookie
    redirect = RedirectResponse("/", status_code=303)
    redirect.set_cookie(key="session", value=session_token, httponly=True, max_age=86400*30)
    return redirect


@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request, session: Optional[str] = Cookie(None)):
    """Страница регистрации"""
    user = get_current_user(session)
    if user:
        return RedirectResponse("/", status_code=303)
    
    return templates.TemplateResponse("register.html", {
        "request": request
    })


@app.post("/register")
async def register(
    response: Response,
    username: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    full_name: str = Form(...),
    phone: str = Form(...),
    address: str = Form(""),
    is_seller: bool = Form(False)
):
    """Обработка регистрации"""
    global user_id_counter
    
    # Проверка существования пользователя
    for u in users_db.values():
        if u.username == username:
            raise HTTPException(status_code=400, detail="Пользователь с таким именем уже существует")
        if u.email == email:
            raise HTTPException(status_code=400, detail="Email уже используется")
    
    # Создание пользователя
    user = User(
        id=user_id_counter,
        username=username,
        email=email,
        password_hash=hash_password(password),
        full_name=full_name,
        phone=phone,
        address=address,
        created_at=datetime.now(),
        is_seller=is_seller,
        avatar=random.choice(["😊", "😎", "🤩", "😋", "🥳", "🤗", "😇", "🌟", "💫", "✨"])
    )
    
    users_db[user.id] = user
    user_id_counter += 1
    
    # Создаем сессию
    session_token = create_session(user.id)
    
    # Редирект с установкой cookie
    redirect = RedirectResponse("/", status_code=303)
    redirect.set_cookie(key="session", value=session_token, httponly=True, max_age=86400*30)
    return redirect


@app.get("/logout")
async def logout(session: Optional[str] = Cookie(None)):
    """Выход"""
    if session and session in sessions_db:
        del sessions_db[session]
    
    redirect = RedirectResponse("/login", status_code=303)
    redirect.delete_cookie("session")
    return redirect


@app.get("/profile", response_class=HTMLResponse)
async def profile(request: Request, session: Optional[str] = Cookie(None)):
    """Профиль пользователя"""
    user = get_current_user(session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    
    # Получаем заказы пользователя
    user_orders = [o for o in orders_db.values() if o.buyer_phone == user.phone]
    user_orders.sort(key=lambda o: o.created_at, reverse=True)
    
    return templates.TemplateResponse("profile.html", {
        "request": request,
        "user": user,
        "orders": user_orders,
        "products_db": products_db
    })


@app.get("/", response_class=HTMLResponse)
async def index(request: Request, category: Optional[str] = None, urgency: Optional[str] = None, session: Optional[str] = Cookie(None)):
    """Главная страница с каталогом продуктов"""
    products = list(products_db.values())
    
    # Фильтрация по категории
    if category and category != "all":
        products = [p for p in products if p.category.value == category]
    
    # Фильтрация по срочности
    if urgency and urgency != "all":
        products = [p for p in products if p.urgency_level == urgency]
    
    # Сортировка по срочности (самые срочные первыми)
    products.sort(key=lambda p: p.hours_left)
    
    # Фильтруем только доступные продукты
    products = [p for p in products if p.quantity > 0]
    
    categories = [cat.value for cat in ProductCategory]
    user = get_current_user(session)
    
    return templates.TemplateResponse("index.html", {
        "request": request,
        "products": products,
        "categories": categories,
        "selected_category": category or "all",
        "selected_urgency": urgency or "all",
        "user": user
    })


@app.get("/product/{product_id}", response_class=HTMLResponse)
async def product_detail(request: Request, product_id: int):
    """Детальная страница продукта"""
    product = products_db.get(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Продукт не найден")
    
    seller = sellers_db.get(product.seller_id)
    
    return templates.TemplateResponse("product.html", {
        "request": request,
        "product": product,
        "seller": seller
    })


@app.post("/order/{product_id}")
async def create_order(
    product_id: int,
    buyer_name: str = Form(...),
    buyer_phone: str = Form(...),
    buyer_address: str = Form(...),
    quantity: int = Form(...)
):
    """Создание заказа"""
    global order_id_counter
    
    product = products_db.get(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Продукт не найден")
    
    if quantity > product.quantity:
        raise HTTPException(status_code=400, detail="Недостаточно товара на складе")
    
    if quantity <= 0:
        raise HTTPException(status_code=400, detail="Количество должно быть больше 0")
    
    # Создаем заказ
    order = Order(
        id=order_id_counter,
        product_id=product_id,
        buyer_name=buyer_name,
        buyer_phone=buyer_phone,
        buyer_address=buyer_address,
        quantity=quantity,
        total_price=product.discounted_price * quantity,
        status=OrderStatus.NEW,
        created_at=datetime.now(),
        delivery_time=datetime.now() + timedelta(minutes=random.randint(30, 90))
    )
    
    orders_db[order.id] = order
    order_id_counter += 1
    
    # Уменьшаем количество товара
    product.quantity -= quantity
    
    return RedirectResponse(f"/order/{order.id}", status_code=303)


@app.get("/order/{order_id}", response_class=HTMLResponse)
async def order_detail(request: Request, order_id: int):
    """Страница заказа"""
    order = orders_db.get(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")
    
    product = products_db.get(order.product_id)
    seller = sellers_db.get(product.seller_id) if product else None
    
    return templates.TemplateResponse("order.html", {
        "request": request,
        "order": order,
        "product": product,
        "seller": seller
    })


@app.get("/seller/dashboard", response_class=HTMLResponse)
async def seller_dashboard(request: Request, seller_id: int = 1):
    """Дашборд продавца"""
    seller = sellers_db.get(seller_id)
    if not seller:
        raise HTTPException(status_code=404, detail="Продавец не найден")
    
    # Получаем продукты продавца
    seller_products = [p for p in products_db.values() if p.seller_id == seller_id]
    
    # Получаем заказы на продукты продавца
    seller_orders = [
        o for o in orders_db.values() 
        if products_db.get(o.product_id) and products_db[o.product_id].seller_id == seller_id
    ]
    seller_orders.sort(key=lambda o: o.created_at, reverse=True)
    
    # Статистика
    total_revenue = sum(o.total_price for o in seller_orders if o.status != OrderStatus.CANCELLED)
    active_products = len([p for p in seller_products if p.quantity > 0])
    
    return templates.TemplateResponse("seller_dashboard.html", {
        "request": request,
        "seller": seller,
        "products": seller_products,
        "orders": seller_orders,
        "total_revenue": round(total_revenue, 2),
        "active_products": active_products,
        "all_sellers": list(sellers_db.values())
    })


@app.post("/seller/add-product")
async def add_product(
    seller_id: int = Form(...),
    name: str = Form(...),
    category: str = Form(...),
    original_price: float = Form(...),
    discount: int = Form(...),
    quantity: int = Form(...),
    hours_until_expiry: int = Form(...),
    description: str = Form(...)
):
    """Добавление нового продукта"""
    global product_id_counter
    
    seller = sellers_db.get(seller_id)
    if not seller:
        raise HTTPException(status_code=404, detail="Продавец не найден")
    
    # Эмодзи для категорий
    category_emojis = {
        "Хлебобулочные изделия": "🥖",
        "Молочные продукты": "🥛",
        "Мясные изделия": "🍖",
        "Готовые блюда": "🍲",
        "Десерты": "🍰",
        "Напитки": "🍊"
    }
    
    product = Product(
        id=product_id_counter,
        name=name,
        category=ProductCategory(category),
        original_price=original_price,
        discount=discount,
        quantity=quantity,
        expiry_date=datetime.now() + timedelta(hours=hours_until_expiry),
        seller_name=seller.name,
        seller_id=seller_id,
        image_url=category_emojis.get(category, "🍴"),
        description=description
    )
    
    products_db[product.id] = product
    product_id_counter += 1
    
    return RedirectResponse(f"/seller/dashboard?seller_id={seller_id}", status_code=303)


@app.post("/seller/update-status/{order_id}")
async def update_order_status(order_id: int, status: str = Form(...), seller_id: int = Form(...)):
    """Обновление статуса заказа"""
    order = orders_db.get(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")
    
    order.status = OrderStatus(status)
    
    return RedirectResponse(f"/seller/dashboard?seller_id={seller_id}", status_code=303)


@app.get("/about", response_class=HTMLResponse)
async def about(request: Request):
    """Страница о сервисе"""
    total_saved = sum(s.total_saved for s in sellers_db.values())
    total_sellers = len(sellers_db)
    total_orders = len([o for o in orders_db.values() if o.status != OrderStatus.CANCELLED])
    
    return templates.TemplateResponse("about.html", {
        "request": request,
        "total_saved": round(total_saved, 1),
        "total_sellers": total_sellers,
        "total_orders": total_orders
    })


@app.get("/api/stats")
async def get_stats():
    """API для получения статистики"""
    total_products = len([p for p in products_db.values() if p.quantity > 0])
    total_value = sum(p.discounted_price * p.quantity for p in products_db.values() if p.quantity > 0)
    urgent_products = len([p for p in products_db.values() if p.urgency_level in ['critical', 'high'] and p.quantity > 0])
    avg_discount = sum(p.discount for p in products_db.values()) / len(products_db) if products_db else 0
    
    return {
        "total_products": total_products,
        "total_value": round(total_value, 2),
        "urgent_products": urgent_products,
        "avg_discount": round(avg_discount, 0),
        "total_saved_kg": round(sum(s.total_saved for s in sellers_db.values()), 1)
    }


@app.get("/api/search")
async def search_products(q: str = ""):
    """Поиск товаров"""
    if not q:
        return []
    
    results = []
    query = q.lower()
    for product in products_db.values():
        if product.quantity > 0 and (
            query in product.name.lower() or 
            query in product.description.lower() or
            query in product.category.value.lower()
        ):
            results.append({
                "id": product.id,
                "name": product.name,
                "price": product.discounted_price,
                "discount": product.discount,
                "category": product.category.value,
                "urgency": product.urgency_level
            })
    
    return results[:10]  # Топ 10 результатов


if __name__ == "__main__":
    print("=" * 70)
    print(" " * 20 + "🍽️  FOODSAVER  🍽️")
    print(" " * 10 + "Сервис продажи продуктов со скидкой")
    print("=" * 70)
    print("\n✅ Все зависимости загружены!")
    print("🚀 Запуск сервера...")
    print("\n📍 Откройте в браузере: http://localhost:8000")
    print("📖 API документация: http://localhost:8000/docs")
    print("\n💡 Тестовые данные:")
    print(f"   • {len(sellers_db)} продавцов")
    print(f"   • {len(products_db)} товаров")
    print(f"   • {len([p for p in products_db.values() if p.urgency_level == 'critical'])} срочных предложений")
    print("\n⌨️  Нажмите Ctrl+C для остановки\n")
    print("-" * 70)
    
    uvicorn.run(app, host="0.0.0.0", port=8000)
